TEAM MEMBERS:   
            Arnav Bansal         : 2018csb1075
            Ritvik               : 2018csb1115
            Sparsh Agarwal       : 2018csb1126
            Keshav Kishore       : 2018eeb1158
            Mahima Kumawat       : 2018eeb1162



THIS IS THE PHASE 3 OF OUR GROUP PROJECT.
IT IS THE PIPELINED EXECUTION (32BIT)
PLEASE GIVE OUT INPUT IN INPUT.MC (FILE HAS ALREADY BEEN CREATED)
YOU WILL GET OUTPUT AS STATS.TXT FILE.
PLEASE COMPILE THE PIPELINE.CPP.

PS - We did not suceed in making the branch predictor so control hazard cases might not run as intended with pipelining turned onSS 